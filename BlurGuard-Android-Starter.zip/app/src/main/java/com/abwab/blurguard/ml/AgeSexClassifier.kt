package com.abwab.blurguard.ml

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.common.FileUtil

class AgeSexClassifier(ctx: Context) {
    private val genderModel = Interpreter(FileUtil.loadMappedFile(ctx, "gender.tflite"))
    private val ageModel = Interpreter(FileUtil.loadMappedFile(ctx, "age.tflite"))

    data class Result(val isChild: Boolean?, val isMale: Boolean?)

    fun classify(faceCropped: Bitmap): Result {
        return Result(isChild = null, isMale = null)
    }
}
