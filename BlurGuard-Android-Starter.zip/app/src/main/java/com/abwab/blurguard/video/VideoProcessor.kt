package com.abwab.blurguard.video

import android.content.Context
import android.net.Uri
import com.abwab.blurguard.BlurMode

object VideoProcessor {
    suspend fun process(ctx: Context, uri: Uri, sensitivity: Float, feather: Float, mode: BlurMode) {
        // TODO implement
    }
}
