package com.abwab.blurguard.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

class ScreenBlurService : Service() {
    override fun onBind(intent: Intent?) = null
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel("blur_guard_overlay", "Blur Overlay", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
            val n: Notification = Notification.Builder(this, "blur_guard_overlay")
                .setContentTitle("Blur overlay running")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()
            startForeground(1, n)
        }
    }
}
