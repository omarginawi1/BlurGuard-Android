package com.abwab.blurguard.ui

import android.content.Intent
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun ImagePicker(onImagePicked: (android.net.Uri) -> Unit, onVideoPicked: (android.net.Uri) -> Unit) {
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        res.data?.data?.let(onImagePicked)
    }
    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        res.data?.data?.let(onVideoPicked)
    }

    Row(Modifier.fillMaxWidth()) {
        Button(onClick = {
            val i = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            i.type = "image/*"
            pickImage.launch(i)
        }) { Text("اختر صورة") }
        Button(onClick = {
            val i = Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            i.type = "video/*"
            pickVideo.launch(i)
        }) { Text("اختر فيديو") }
    }
}
