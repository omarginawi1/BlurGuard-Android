package com.abwab.blurguard.segmentation

import android.content.Context
import android.graphics.*
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.SegmentationMask
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenter
import kotlinx.coroutines.tasks.await

class SelfieSegmenter(ctx: Context) {
    private val options = SelfieSegmenterOptions.Builder()
        .setDetectorMode(SelfieSegmenterOptions.STREAM_MODE)
        .build()
    private val client = SelfieSegmenter.getClient(options)

    fun toBitmap(imageProxy: ImageProxy): Bitmap {
        throw NotImplementedError("Implement ImageProxy to Bitmap conversion")
    }

    suspend fun segment(bitmap: Bitmap, threshold: Float): Bitmap {
        val img = InputImage.fromBitmap(bitmap, 0)
        val result: SegmentationMask = client.process(img).await()
        val maskBuffer = result.buffer
        val w = result.width
        val h = result.height
        val maskBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ALPHA_8)
        val pixels = ByteArray(w*h)
        maskBuffer.rewind()
        var i = 0
        while (maskBuffer.hasRemaining()) {
            val v = maskBuffer.float
            pixels[i++] = if (v >= threshold) 0xFF.toByte() else 0x00
        }
        maskBmp.copyPixelsFromBuffer(java.nio.ByteBuffer.wrap(pixels))
        return maskBmp
    }
}
