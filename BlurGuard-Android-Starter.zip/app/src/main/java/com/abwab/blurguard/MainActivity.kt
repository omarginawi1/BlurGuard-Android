package com.abwab.blurguard

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.abwab.blurguard.ui.CameraPreviewComposable
import com.abwab.blurguard.ui.ImagePicker
import com.abwab.blurguard.video.VideoProcessor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var blurMode by remember { mutableStateOf(BlurMode.EVERYONE) }
    var sensitivity by remember { mutableStateOf(0.6f) }
    var feather by remember { mutableStateOf(6f) }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {}

    LaunchedEffect(Unit) {
        permLauncher.launch(arrayOf(Manifest.permission.CAMERA))
    }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("BlurGuard – People Blur") }) }) { padding ->
            Column(Modifier.padding(padding).padding(12.dp)) {
                Text("Mode")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        BlurMode.EVERYONE to "الجميع",
                        BlurMode.ADULTS to "البالغون",
                        BlurMode.CHILDREN to "الأطفال",
                        BlurMode.MEN to "الرجال",
                        BlurMode.WOMEN to "النساء"
                    ).forEach { (mode, label) ->
                        FilterChip(
                            selected = blurMode == mode,
                            onClick = { blurMode = mode },
                            label = { Text(label) }
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("الحساسية (العتبة): ${"%.2f".format(sensitivity)}")
                Slider(value = sensitivity, onValueChange = { sensitivity = it }, valueRange = 0.3f..0.9f)
                Text("تنعيم الحواف (Feather): ${"%.0f".format(feather)}px")
                Slider(value = feather, onValueChange = { feather = it }, valueRange = 0f..24f)

                Spacer(Modifier.height(8.dp))
                Card(Modifier.fillMaxWidth()) {
                    CameraPreviewComposable(sensitivity, feather, blurMode)
                }

                Spacer(Modifier.height(12.dp))
                ImagePicker(
                    onImagePicked = { /* TODO wire ImagePipeline */ },
                    onVideoPicked = { uri ->
                        scope.launch(Dispatchers.Default) {
                            VideoProcessor.process(ctx, uri, sensitivity, feather, blurMode)
                        }
                    }
                )
            }
        }
    }
}

enum class BlurMode { EVERYONE, ADULTS, CHILDREN, MEN, WOMEN }
