package com.abwab.blurguard.ui

import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.abwab.blurguard.BlurMode
import com.abwab.blurguard.pipeline.FrameBlurrer
import com.abwab.blurguard.segmentation.SelfieSegmenter

@Composable
fun CameraPreviewComposable(
    sensitivity: Float,
    feather: Float,
    blurMode: BlurMode
) {
    val ctx = LocalContext.current
    val segmenter = remember { SelfieSegmenter(ctx) }
    val blurrer = remember { FrameBlurrer(ctx) }

    AndroidView(
        modifier = Modifier.fillMaxWidth().aspectRatio(9f / 16f),
        factory = { context ->
            val preview = PreviewView(context)
            val controller = LifecycleCameraController(context)
            controller.setImageAnalysisAnalyzer(ContextCompat.getMainExecutor(context), ImageAnalysis.Analyzer { imageProxy ->
                // TODO: implement toBitmap and segmentation; preview update placeholder
                imageProxy.close()
            })
            preview.controller = controller
            controller.bindToLifecycle(context as androidx.lifecycle.LifecycleOwner)
            preview
        }
    )
}
