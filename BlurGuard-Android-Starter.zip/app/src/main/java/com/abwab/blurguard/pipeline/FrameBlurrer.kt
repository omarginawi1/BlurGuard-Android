package com.abwab.blurguard.pipeline

import android.content.Context
import android.graphics.*
import android.os.Build
import android.view.RenderEffect

class FrameBlurrer(private val ctx: Context) {
    fun blurByMask(frame: Bitmap, mask: Bitmap, featherPx: Float): Bitmap {
        val out = frame.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)

        val blurred = if (Build.VERSION.SDK_INT >= 31) {
            val tmp = frame.copy(Bitmap.Config.ARGB_8888, false)
            val c = Canvas(tmp)
            val p = Paint()
            p.renderEffect = RenderEffect.createBlurEffect(20f, 20f, android.graphics.Shader.TileMode.CLAMP)
            c.drawBitmap(frame, 0f, 0f, p)
            tmp
        } else {
            frame // placeholder
        }

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        if (featherPx > 0) maskPaint.maskFilter = BlurMaskFilter(featherPx, BlurMaskFilter.Blur.NORMAL)

        val maskScaled = Bitmap.createScaledBitmap(mask, frame.width, frame.height, true)
        val layer = canvas.saveLayer(0f,0f, frame.width.toFloat(), frame.height.toFloat(), null)
        canvas.drawBitmap(maskScaled, 0f, 0f, maskPaint)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        canvas.drawBitmap(blurred, 0f, 0f, paint)
        paint.xfermode = null
        canvas.restoreToCount(layer)
        return out
    }
}
