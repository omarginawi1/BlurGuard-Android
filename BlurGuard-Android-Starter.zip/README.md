# BlurGuard (Ready-to-import)
1) نزّل Android Studio وافتح هذا المجلد كـ Project.
2) أول تشغيل قد يطلب تنزيل مكوّنات؛ وافق.
3) لبناء APK: Build > Build APK(s). سيظهر المسار في الإشعار.

> ملاحظة: ملف Gradle wrapper غير مرفق لتقليل الحجم؛
عند فتح المشروع سيقوم Android Studio بتنزيل Gradle تلقائياً.
